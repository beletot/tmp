<?php
// no direct access
defined('_JEXEC') or die('Restricted access');
/*if ($gmailunreadcount >= 1) {
    $stringEmail = '<img src="images/messaging.png" title="'.JText::sprintf('TITLE_EMAILUNREAD', $gmailunreadcount).'" ><br />';
    $stringEmail .= JText::sprintf('EMAILUNREAD', $gmailunreadcount);
} else {
    $stringEmail = JText::_('EMAIL');
    ;
}*/
?>
<div class="mod-<?php echo $params->get( 'moduleclass_sfx' ) ?>">
    <table width="200">
        <tr>
            <td width="50%" align="center" valign="bottom">
                <a href="http://mail.google.com/a/epfc.eu" class="" title="<?php echo JText::_('EMAIL'); ?>" target="_blank">
                	<img src="/images/messaging.png" title="Accéder à votre boite mail">
                	<br />
                    <?php echo JText::_('EMAIL'); ?>
                </a>
            </td>
            <td align="center" valign="bottom">
                <?php if($GoogleModalBox) {?>
				<a rel="{handler: 'iframe', size: {x: 782, y: 650}}" href="index.php?option=com_calendar&tmpl=component" class="modal" title="<?php echo JText::_( 'MY_CALENDAR' ); ?>">
                	<img src="/images/month_f2.png" title="<?php echo JText::_('CALENDAR'); ?>">
                    <br/>
                    <?php echo JText::_('CALENDAR'); ?>
                </a>
                <?php }else{?>
                <a href="http://calendar.google.com/a/epfc.eu" title="<?php echo JText::_( 'MY_CALENDAR' ); ?>" target="_blank">
                	<img src="/images/month_f2.png" title="<?php echo JText::_('CALENDAR'); ?>">
                    <br/>
                    <?php echo JText::_('CALENDAR'); ?>
                </a>
                <?php }?>
                
            </td>
        </tr>
        <tr style="display:none;">
            <td align="right" colspan="2">
                <a href="index.php?option=com_myepfc" title="<?php echo JText::_('OTHER_OPTIONS'); ?>">
                    <?php echo JText::_('OTHER_OPTIONS'); ?>
                </a>
            </td>
        </tr>
    </table>
</div>
