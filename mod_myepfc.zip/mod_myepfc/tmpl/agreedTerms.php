<?php
// no direct access
defined('_JEXEC') or die('Restricted access');
//echo 'Has Agreed To Terms: '.($user->login->agreedToTerms ? 'Yes' : 'No')."<br />";
?>
<div class="mod-<?php echo $params->get( 'moduleclass_sfx' ) ?>">
    <table width="200">
        <tr>
            <td align="left" valign="bottom">
				<a rel="{handler: 'iframe', size: {x: 960, y: 800}}" href="index.php?option=com_calendar&tmpl=component" class="modal" title="<?php echo JText::_('AGREED_TERMS'); ?>">
                    <img src="images/smilies/big-smile.png" align="left" style="padding-right:10px;" />
					<?php echo JText::_('AGREED_TERMS'); ?>
                </a>
            </td>
        </tr>
    </table>
</div>