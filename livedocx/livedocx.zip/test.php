<?php

$nom = './';
$nomOrigineFichier = 'arnold.doc';
$nomUnique = 'arnold.pdf';

/* --- GENERATION DU PDF---*/
// Turn up error reporting
error_reporting(E_ALL | E_STRICT);

// Turn off WSDL caching
ini_set('soap.wsdl_cache_enabled', 0);

// Define credentials for LD
define('COPIEPDF_USERNAME', '');
define('COPIEPDF_PASSWORD', '');


// SOAP WSDL endpoint
define('ENDPOINT', 'https://api.livedocx.com/1.2/mailmerge.asmx?WSDL');

// Define timezone
date_default_timezone_set('Europe/Berlin');

// -----------------------------------------------------------------------------
//
// SAMPLE #1 - License Agreement
//
print('Début de la conversion de votre fichier...');
// Instantiate SOAP object and log into LiveDocx
$soap = new SoapClient(ENDPOINT);
$soap->LogIn(array(
    'username' => COPIEPDF_USERNAME , 
    'password' => COPIEPDF_PASSWORD
));

// Upload template
//chdir("document/$nom");
$data = file_get_contents("$nom/$nomOrigineFichier");
$soap->SetLocalTemplate(array(
    'template' => base64_encode($data) , 'format' => 'doc'
));

// Assign data to template
/*
$fieldValues = array (
'software' => 'Magic Graphical Compression Suite v2.5',
'licensee' => 'Henry D�ner-Meyer',
'company' => 'Megasoft Co-Operation',
'date' => date('F d, Y'),
'time' => date('H:i:s'),
'city' => 'Berlin',
'country' => 'Germany'
);

$soap->SetFieldValues(
array (
'fieldValues' => assocArrayToArrayOfArrayOfString($fieldValues)
)
);
*/

// Build the document
$soap->CreateDocument();

// Get document as PDF
$result = $soap->RetrieveDocument(array(
    'format' => 'pdf'
));

$data = $result->RetrieveDocumentResult;

file_put_contents("$nom/$nomUnique", base64_decode($data));

// Log out (closes connection to backend server)
$soap->LogOut();
unset($soap);
print('DONE.' . PHP_EOL);

?>
