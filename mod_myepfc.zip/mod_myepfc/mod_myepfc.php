<?php
/**
 * @version		$Id: mod_mainmenu.php 10381 2008-06-01 03:35:53Z pasamio $
 * @package		Joomla
 * @copyright	Copyright (C) 2005 - 2008 Open Source Matters. All rights reserved.
 * @license		GNU/GPL, see LICENSE.php
 * Joomla! is free software. This version may have been modified pursuant
 * to the GNU General Public License, and as distributed it includes or
 * is derivative of works licensed under the GNU General Public License or
 * other free or open source software licenses.
 * See COPYRIGHT.php for copyright notices and details.
 */

// no direct access
//defined('_JEXEC') or die('Restricted access');
echo 'kjhkj';

// Include the syndicate functions only once
require_once (dirname(__FILE__).DS.'helper.php');
require_once (JPATH_ROOT.DS.'libraries'.DS.'simplesamlphp'.DS.'lib'.DS.'_autoload.php');
require_once (JPATH_ROOT.DS.'components'.DS.'com_calendar'.DS.'helper'.DS.'googleCalendar.php');
$type = modLoginHelper::getType();
$return = modLoginHelper::getReturnURL($params, $type);

$user = &JFactory::getUser();
$samlAuth = new SimpleSAML_Auth_Simple('example-mysql');
$samlSession = SimpleSAML_Session::getInstance();
// ie browser check
if (array_key_exists('HTTP_USER_AGENT', $_SERVER)) {
	$navigator = strtolower($_SERVER['HTTP_USER_AGENT']);
	switch ($navigator) {
	case strpos($navigator,'msie 8') == true:
	    $GoogleModalBox = false;
	    break;
	case strpos($navigator,'msie 7') == true:
	    $GoogleModalBox = false;
	    break;
	case strpos($navigator,'msie 6') == true:
		$GoogleModalBox = false;
	    break;
	default:
	    $GoogleModalBox = true;
	    break;
	}
} else {
	$GoogleModalBox = false;
}
//get user apps
if($gdata = googleCalendar::connexionApps()){
	$userApps = $gdata->retrieveUser($user->username);
	$userApps->login->agreedToTerms;

	//$params->def('menutype', 			'mainmenu');
	//$gmailunreadcount = modMyepfcHelper::gmailUnreadMail();
	$list = array();
	if ($type == 'logout' && $samlAuth->isAuthenticated() == 1) {
		if($userApps->login->agreedToTerms == NULL){	
			require (JModuleHelper::getLayoutPath('mod_myepfc','agreedTerms'));
		}else{
			require (JModuleHelper::getLayoutPath('mod_myepfc'));	
		} 
	}
}else{
	echo 'Oups nous rencontrons un problème, nous en cherchons <br />la cause.
		Vous pouvez utiliser l\'adresse <a href="http://mail.epfc.eu" target="blank"> mail.epfc.eu</a> pour lire vos mails.';
}
